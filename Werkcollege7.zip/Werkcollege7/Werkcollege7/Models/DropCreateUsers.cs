﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Werkcollege7.Models
{
    public class DropCreateUsers: DropCreateDatabaseIfModelChanges<We7Context>
    {
        protected override void Seed(We7Context context)
        {
            base.Seed(context);
            context.Users.Add(new User { Username = "Jos", Wachtwoord = "123" });
            context.SaveChanges();
        }
    }
}