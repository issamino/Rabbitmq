﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Werkcollege7.Models;

namespace Werkcollege7.Controllers
{
    public class VoorstellingController : ApiController
    {
        private We7Context db = new We7Context();

        // GET api/Voorstelling
        public IEnumerable<Voorstelling> GetVoorstellingen()
        {
            var voorstellingen = db.Voorstellingen.Include(v => v.Zaal).Include(v => v.Film).OrderBy(v=>v.Begin);
            return voorstellingen.AsEnumerable();
        }

        // GET api/Voorstelling/5
        public Voorstelling GetVoorstelling(int id)
        {
            Voorstelling voorstelling = db.Voorstellingen.Find(id);
            if (voorstelling == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return voorstelling;
        }

        // PUT api/Voorstelling/5
        [Authorize]
        public HttpResponseMessage PutVoorstelling(int id, [FromBody]Voorstelling voorstelling)
        {
            if (ModelState.IsValid && id == voorstelling.Id)
            {
                db.Entry(voorstelling).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/Voorstelling
        [Authorize]
        public HttpResponseMessage PostVoorstelling([FromBody]Voorstelling voorstelling)
        {
            if (ModelState.IsValid)
            {
                db.Voorstellingen.Add(voorstelling);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, voorstelling);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = voorstelling.Id }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/Voorstelling/5
        [Authorize]
        public HttpResponseMessage DeleteVoorstelling(int id)
        {
            Voorstelling voorstelling = db.Voorstellingen.Find(id);
            if (voorstelling == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Voorstellingen.Remove(voorstelling);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, voorstelling);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}