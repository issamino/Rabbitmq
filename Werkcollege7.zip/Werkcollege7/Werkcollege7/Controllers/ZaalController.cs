﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Werkcollege7.Models;

namespace Werkcollege7.Controllers
{
    public class ZaalController : ApiController
    {
        private We7Context db = new We7Context();

        // GET api/Zaal
        public IEnumerable<Zaal> GetZalen()
        {
            return db.Zalen.AsEnumerable();
        }

        // GET api/Zaal/5
        public Zaal GetZaal(int id)
        {
            Zaal zaal = db.Zalen.Find(id);
            if (zaal == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return zaal;
        }

        // PUT api/Zaal/5
        [Authorize]
        public HttpResponseMessage PutZaal(int id,[FromBody]Zaal zaal)
        {
            if (ModelState.IsValid && id == zaal.Nummer)
            {
                db.Entry(zaal).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/Zaal
        [Authorize]
        public HttpResponseMessage PostZaal([FromBody]Zaal zaal)
        {
            if (ModelState.IsValid)
            {
                if(db.Zalen.Where(m=>m.Nummer==zaal.Nummer).Count()>0)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                db.Zalen.Add(zaal);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, zaal);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = zaal.Nummer }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/Zaal/5
        [Authorize]
        public HttpResponseMessage DeleteZaal(int id)
        {
            Zaal zaal = db.Zalen.Find(id);
            if (zaal == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Zalen.Remove(zaal);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, zaal);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}