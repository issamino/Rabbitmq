<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once '/PSWebServiceLibrary.php';
use PhpAmqpLib\Connection\AMQPConnection;
use PhpAmqpLib\Message\AMQPMessage;



global $connection;
global $channel;

function getCustomer($id)
{
$check = false;
$connection = new AMQPConnection('10.3.51.38', 5672, 'admin', 'admin124');
$channel = $connection->channel();
$channelErrors = $connection->channel();

$channel->queue_declare('Customers', false, true, false, false);
$channelErrors->queue_declare('Errors', false, true, false, false);

  $webService = new PrestaShopWebService('http://10.3.51.42/hotel2/intourist/','2YJEYH5SF96CRBB97VR5CRT37KDZG4XZ',false);

$xml = $webService->get(array('resource'=>'customers','id'=>$id));

if($xml == null)
{	
//echo "test";
$data = "Customer with id ".$id. " does not exist...";
$msg = new AMQPMessage($data, array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
$channelErrors->basic_publish($msg, '', 'Errors');
echo " [x] Sent to Errors: ", $data, "\n";

}	
else{
$customerNodes = $xml->children()->children();
$customers = array();


  $firstname = (string) $customerNodes->firstname;
  $lastname =  (string) $customerNodes->lastname;
  $cid = (int) $customerNodes->id;
  $check = true;
}
if($cid == $id){
$customers[] = array('firstname' => $firstname, 'lastname' => $lastname, 'id' => $cid);
  
  $data = json_encode($customers);
$msg = new AMQPMessage($data, array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
$channel->basic_publish($msg, '', 'Customers');
echo " [x] Sent to Hotel: ", $data, "\n";

$check = true;
  }
  else{

	 // $data = json_encode("Customer not found!");

$check = false;
  }



//header('Location: form.php?sent=true');



$channel->close();
$connection->close();

return $check;
}

function sendCustomer($id){

$connection = new AMQPConnection('10.3.51.38', 5672, 'admin', 'admin124');
$channel = $connection->channel();

$channel->queue_declare('CRM', false, true, false, false);

//

 $webService = new PrestaShopWebService('http://10.3.51.42/hotel2/intourist/','2YJEYH5SF96CRBB97VR5CRT37KDZG4XZ',false);

$xml = $webService->get(array('resource'=>'customers','id'=>$id));

	


$customerNodes = $xml->children()->children();
$customers = array();


  $firstname = (string) $customerNodes->firstname;
  $lastname =  (string) $customerNodes->lastname;
  $cid = (int) $customerNodes->id;


$customers[] = array('firstname' => $firstname, 'lastname' => $lastname, 'id' => $cid);
  
  $data = json_encode($customers);


  

//
$data = json_encode($customers);

$msg = new AMQPMessage($data, array('delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
$channel->basic_publish($msg, '', 'CRM');

//header('Location: form.php?sent=true');

echo " [x] Sent to CRM: ", $data, "\n";


$channel->close();
$connection->close();

}
?>

