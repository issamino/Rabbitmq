﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Werkcollege7.Models
{
    [Table("Voorstellingen")]
    public class Voorstelling
    {
        public int Id { get; set; }
        [ForeignKey("Zaal")]
        public int ZaalId { get; set; }
        public Zaal Zaal { get; set; }
        [ForeignKey("Film")]
        public int FilmId { get; set; }
        public Film Film { get; set; }
        public DateTime Begin { get; set; }
        public DateTime Einde { get; set; }
    }
}