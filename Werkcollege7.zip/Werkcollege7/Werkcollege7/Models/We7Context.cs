﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Werkcollege7.Models
{
    public class We7Context:DbContext
    {
        public We7Context()
            : base("MijnDB")
        {
        }

        public DbSet<Film> Films { get; set; }
        public DbSet<Zaal> Zalen { get; set; }
        public DbSet<Voorstelling> Voorstellingen { get; set; }
        public DbSet<User> Users { get; set; }
    }
}