﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Werkcollege7.Models;

namespace Werkcollege7.Controllers
{
    public class FilmController : ApiController
    {
        private We7Context db = new We7Context();

        // GET api/Film
        public IEnumerable<Film> GetFilms()
        {
            return db.Films.AsEnumerable();
        }

        // GET api/Film/5
        public Film GetFilm(int id)
        {
            Film film = db.Films.Find(id);
            if (film == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return film;
        }

        // PUT api/Film/5
        [Authorize]
        public HttpResponseMessage PutFilm(int id, [FromBody]Film film)
        {
            if (ModelState.IsValid && id == film.Id)
            {
                db.Entry(film).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/Film
        [Authorize]
        public HttpResponseMessage PostFilm([FromBody]Film film)
        {
            if (ModelState.IsValid)
            {
                db.Films.Add(film);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, film);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = film.Id }));
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/Film/5
        [Authorize]
        public HttpResponseMessage DeleteFilm(int id)
        {
            Film film = db.Films.Find(id);
            if (film == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Films.Remove(film);
            foreach (Voorstelling v in db.Voorstellingen.Where(m => m.FilmId == film.Id).ToList())
                db.Voorstellingen.Remove(v);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, film);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}