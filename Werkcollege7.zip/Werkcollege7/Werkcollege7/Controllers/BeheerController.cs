﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Security.Claims;
using Werkcollege7.Models;
using Microsoft.Owin.Security;
using Microsoft.AspNet.Identity;
namespace Werkcollege7.Controllers
{
    public class BeheerController : Controller
    {

        private We7Context c = new We7Context();

        [Authorize]
        public ActionResult Overview()
        {
            return View();
        }

        [Authorize]
        public ActionResult FilmToevoegen()
        {
            return View();
        }

        [Authorize]
        public ActionResult ZaalToevoegen()
        {
            return View();
        }

        [Authorize]
        public ActionResult VoorstellingToevoegen()
        {
            ViewBag.Zalen = new SelectList(c.Zalen.ToList(), "Id", "Nummer");
            ViewBag.Films = new SelectList(c.Films.ToList(), "Id", "Id");
            return View();
        }

        public ActionResult Login()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return View();
            }
            else
                return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User u)
        {

            if (ModelState.IsValid && c.Users.Where(m => m.Username == u.Username && m.Wachtwoord == u.Wachtwoord).Count() > 0)
            {
                var identity = new ClaimsIdentity(new[] {
                            new Claim(ClaimTypes.Name, u.Username),
                        },
                    DefaultAuthenticationTypes.ApplicationCookie,
                    ClaimTypes.Name, ClaimTypes.Role);
                identity.AddClaim(new Claim(ClaimTypes.Role, "guest"));

                HttpContext.GetOwinContext().Authentication.SignIn(new AuthenticationProperties
                {
                    IsPersistent = true
                }, identity);

                return RedirectToAction("Overview", "Beheer");
            }

            else
            {
                u.Wachtwoord = "";
                ViewBag.Failed = "Ongeldige gegevens";
                return View(u);
            }
        }

        [Authorize]
        public ActionResult LogOut()
        {
            HttpContext.GetOwinContext().Authentication.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("Login", "Beheer");
        }

    }
}
