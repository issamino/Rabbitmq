﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Werkcollege7.Models
{
    [Table("Zalen")]
    public class Zaal
    {
        [Key]
        public int Id { get; set; }
        public int Nummer { get; set; }
        public int AantalZitplaatsen { get; set; }
    }
}